/*  Copyright (c) 2015 Ryan Castellucci, All Rights Reserved */
#ifndef __BRAINFLAYER_HSEARCHF_H_
#define __BRAINFLAYER_HSEARCHF_H_

int hsearchf(FILE *, hash160_t *);

/* vim: set ts=2 sw=2 et ai si: */
#endif /* __BRAINFLAYER_HSEARCHF_H_ */
