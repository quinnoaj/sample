/*  Copyright (c) 2015 Ryan Castellucci, All Rights Reserved */
#ifndef __BRAINFLAYER_BRAINV2_H_
#define __BRAINFLAYER_BRAINV2_H_

int brainv2(unsigned char *, size_t, unsigned char *, size_t, unsigned char *);

/* vim: set ts=2 sw=2 et ai si: */
#endif /* __BRAINFLAYER_BRAINV2_H_ */
